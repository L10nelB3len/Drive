import pygame
import random
import sys

# ---------------------------------------------
# Configuración básica
# ---------------------------------------------
pygame.init()
WIDTH, HEIGHT = 1000, 600
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Cumple - Menú con Juegos y Poema")

CLOCK = pygame.time.Clock()
FPS = 60

# Paleta
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
STAR_COLORS = [(255, 255, 255), (255, 240, 200), (200, 220, 255)]
FIESTA_COLORS = [
    (255, 80, 80),
    (255, 180, 60),
    (255, 255, 80),
    (80, 255, 120),
    (80, 200, 255),
    (180, 100, 255),
]

# Fuentes
TITLE_FONT = pygame.font.SysFont("Arial", 56, bold=True)
MENU_FONT = pygame.font.SysFont("Arial", 34, bold=True)
POEM_FONT = pygame.font.SysFont("Georgia", 30)

# ---------------------------------------------
# Fondo estelar animado
# ---------------------------------------------
class Star:
    def __init__(self):
        self.reset(random.randint(0, WIDTH), random.randint(0, HEIGHT))

    def reset(self, x=None, y=None):
        self.x = x if x is not None else random.randint(0, WIDTH)
        self.y = y if y is not None else random.randint(0, HEIGHT)
        self.speed = random.uniform(0.5, 2.2)
        self.size = random.randint(1, 3)
        self.color = random.choice(STAR_COLORS)

    def update(self):
        # Movimiento suave hacia la izquierda (parallax simple)
        self.x -= self.speed
        if self.x < -5:
            self.reset(WIDTH + random.randint(0, 50), random.randint(0, HEIGHT))

    def draw(self, surf):
        pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), self.size)

class StarField:
    def __init__(self, count=200):
        self.stars = [Star() for _ in range(count)]

    def update(self):
        for s in self.stars:
            s.update()

    def draw(self, surf):
        surf.fill((10, 10, 25))  # Fondo noche
        for s in self.stars:
            s.draw(surf)

# ---------------------------------------------
# Botón con hover multicolor tipo “fiesta”
# ---------------------------------------------
class Button:
    def __init__(self, text, font, center_pos, base_color=WHITE, hover_colors=None, padding=(20, 10)):
        self.text = text
        self.font = font
        self.center_pos = center_pos
        self.base_color = base_color
        self.colors = hover_colors or FIESTA_COLORS
        self.padding = padding
        self.color_index = 0
        self.color_timer = 0
        self.color_interval = 120  # ms entre cambios de color
        self.hover = False
        self.rect = None
        self.render_surface()

    def render_surface(self, color=None):
        color = color or self.base_color
        text_surf = self.font.render(self.text, True, color)
        w = text_surf.get_width() + self.padding[0] * 2
        h = text_surf.get_height() + self.padding[1] * 2
        self.rect = pygame.Rect(0, 0, w, h)
        self.rect.center = self.center_pos
        # Superficie para dibujar el botón (bordes suaves, sin caja)
        self.surf = pygame.Surface((w, h), pygame.SRCALPHA)
        self.surf.fill((0, 0, 0, 0))
        # Opcional: resplandor leve bajo el texto
        glow_color = (color[0], color[1], color[2], 40)
        glow = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.ellipse(glow, glow_color, glow.get_rect())
        self.surf.blit(glow, (0, 0))
        # Dibujar texto centrado
        self.surf.blit(text_surf, (self.padding[0], self.padding[1]))

    def update(self, dt, mouse_pos):
        self.hover = self.rect.collidepoint(mouse_pos)
        if self.hover:
            self.color_timer += dt
            if self.color_timer >= self.color_interval:
                self.color_timer = 0
                self.color_index = (self.color_index + 1) % len(self.colors)
            self.render_surface(self.colors[self.color_index])
        else:
            self.render_surface(self.base_color)

    def draw(self, surf):
        surf.blit(self.surf, self.rect.topleft)

    def is_clicked(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)

# ---------------------------------------------
# Texto tipo máquina de escribir para el poema
# ---------------------------------------------
class TypewriterText:
    def __init__(self, text_lines, font, color=WHITE, interval_ms=40, center_x=True, line_spacing=8):
        self.lines = text_lines
        self.font = font
        self.color = color
        self.interval_ms = interval_ms
        self.center_x = center_x
        self.line_spacing = line_spacing
        self.reset()

    def reset(self):
        self.current_chars = [0 for _ in self.lines]
        self.line_index = 0
        self.timer = 0
        self.done = False

    def update(self, dt):
        if self.done:
            return
        self.timer += dt
        while self.timer >= self.interval_ms and not self.done:
            self.timer -= self.interval_ms
            self.current_chars[self.line_index] += 1
            if self.current_chars[self.line_index] >= len(self.lines[self.line_index]):
                # Pasar a la siguiente línea
                self.line_index += 1
                if self.line_index >= len(self.lines):
                    self.done = True

    def draw(self, surf, start_y):
        y = start_y
        for i, line in enumerate(self.lines):
            visible = line[:self.current_chars[i]]
            text_surf = self.font.render(visible, True, self.color)
            if self.center_x:
                x = (surf.get_width() - text_surf.get_width()) // 2
            else:
                x = 60
            surf.blit(text_surf, (x, y))
            y += text_surf.get_height() + self.line_spacing

# ---------------------------------------------
# Estados del juego
# ---------------------------------------------
MENU = "MENU"
GAME1 = "GAME1"
GAME2 = "GAME2"
GAME3 = "GAME3"
CREDITS = "CREDITS"

def main():
    state = MENU
    stars = StarField(count=220)

    # Botón superior: Feliz cumpleaños (lleva a “Créditos/Poema”)
    btn_title = Button("Feliz cumpleaños", TITLE_FONT, center_pos=(WIDTH // 2, 80))

    # Menú de tres juegos (placeholders)
    btn_game1 = Button("Juego 1", MENU_FONT, center_pos=(WIDTH // 2, 220))
    btn_game2 = Button("Juego 2", MENU_FONT, center_pos=(WIDTH // 2, 300))
    btn_game3 = Button("Juego 3", MENU_FONT, center_pos=(WIDTH // 2, 380))

    # Pie de página
    footer_font = pygame.font.SysFont("Arial", 20)
    footer_text = footer_font.render("Hecho con amor por Lionel", True, (200, 200, 220))

    # Poema (créditos)
    poem_lines = [
        "Mamá, en esta noche de estrellas te celebro,",
        "por cada abrazo que calma, por cada risa que ilumina.",
        "Tu fuerza me guía, tu ternura me enseña,",
        "y en cada paso que doy, siento tu mano y tu fe.",
        "",
        "Feliz cumpleaños. Que tus sueños brillen como este cielo,",
        "y que la vida te abrace con la misma bondad que vos nos das."
    ]
    poem = TypewriterText(poem_lines, POEM_FONT, color=(245, 245, 255), interval_ms=35)

    # Botón para volver del poema al menú
    btn_back = Button("Volver al menú", MENU_FONT, center_pos=(WIDTH // 2, HEIGHT - 80))

    # TODO: Cargar tu fondo de créditos (imagen). Reemplaza 'credits_bg' por tu asset.
    credits_bg = None  # pygame.image.load("ruta/a/tu_fondo_creditos.png").convert()

    running = True
    while running:
        dt = CLOCK.tick(FPS)  # ms
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                mouse_pos = pygame.mouse.get_pos()
                if state == MENU:
                    if btn_title.is_clicked(mouse_pos):
                        # Ir a créditos (poema)
                        state = CREDITS
                        poem.reset()  # Reiniciar efecto de tipeo
                    elif btn_game1.is_clicked(mouse_pos):
                        state = GAME1
                    elif btn_game2.is_clicked(mouse_pos):
                        state = GAME2
                    elif btn_game3.is_clicked(mouse_pos):
                        state = GAME3
                elif state in (GAME1, GAME2, GAME3):
                    # Regresar al menú con clic derecho o tecla ESC en estos placeholders
                    pass
                elif state == CREDITS:
                    if btn_back.is_clicked(mouse_pos):
                        state = MENU

        mouse_pos = pygame.mouse.get_pos()

        # Actualizar fondo estelar
        stars.update()

        # Render por estado
        if state == MENU:
            # Actualizar botones con hover fiesta
            btn_title.update(dt, mouse_pos)
            btn_game1.update(dt, mouse_pos)
            btn_game2.update(dt, mouse_pos)
            btn_game3.update(dt, mouse_pos)

            # Dibujo
            stars.draw(SCREEN)
            btn_title.draw(SCREEN)
            btn_game1.draw(SCREEN)
            btn_game2.draw(SCREEN)
            btn_game3.draw(SCREEN)

            SCREEN.blit(footer_text, (20, HEIGHT - 30))

        elif state in (GAME1, GAME2, GAME3):
            # Placeholder de juegos: muestra el nombre y una tecla para volver
            stars.draw(SCREEN)
            label = MENU_FONT.render(
                f"{'Juego 1' if state == GAME1 else 'Juego 2' if state == GAME2 else 'Juego 3'} - Placeholder",
                True, WHITE
            )
            SCREEN.blit(label, ((WIDTH - label.get_width()) // 2, HEIGHT // 2 - 30))
            hint = footer_font.render("Pulsa ESC para volver al menú", True, (200, 200, 220))
            SCREEN.blit(hint, ((WIDTH - hint.get_width()) // 2, HEIGHT // 2 + 20))

            # Volver con ESC
            keys = pygame.key.get_pressed()
            if keys[pygame.K_ESCAPE]:
                state = MENU

        elif state == CREDITS:
            stars.draw(SCREEN)

            # Fondo de créditos si lo tienes
            if credits_bg:
                # Dibuja la imagen con cierta transparencia para que se vea el campo de estrellas
                bg = credits_bg.copy()
                bg.set_alpha(180)
                SCREEN.blit(bg, (0, 0))

            # Título superior pequeño
            small_title = pygame.font.SysFont("Arial", 28, bold=True).render("Poema", True, (220, 220, 255))
            SCREEN.blit(small_title, ((WIDTH - small_title.get_width()) // 2, 30))

            # Actualizar y dibujar poema
            poem.update(dt)
            poem.draw(SCREEN, start_y=120)

            # Botón volver
            btn_back.update(dt, mouse_pos)
            btn_back.draw(SCREEN)

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
