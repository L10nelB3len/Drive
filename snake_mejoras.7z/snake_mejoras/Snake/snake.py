import sys, os
import pygame
import random
import json
from pygame.math import Vector2
from datetime import datetime

# --- CONFIGURACIÓN DE RUTA DE ARCHIVOS ---
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

try:
    from notificaciones.email_notifier import send_email_notification
except ModuleNotFoundError:
    print("Error importando notificaciones. La función de email no estará disponible.")
    send_email_notification = None


pygame.init()
try:
    pygame.mixer.init()
except Exception:
    print("Advertencia: pygame.mixer no pudo inicializarse completamente.")

# Configuración general 
cell_size = 25
number_of_cells = 25
OFFSET = 60
ANCHO = 2 * OFFSET + cell_size * number_of_cells
ALTO = OFFSET + cell_size * number_of_cells + 80

# Colores
GRID_LIGHT = (140, 160, 70)
GRID_DARK = (110, 130, 50)
SNAKE_COLOR_BLUE = (0, 100, 255)
DARK_GREEN = (43, 51, 24)
GREEN_LIGHT_HOVER = (173, 204, 96)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
WALL_COLOR_DARK_GREY = (60, 60, 60)
FOOD_COLOR_APPLE_RED = (200, 0, 0)
GRAY = (150, 150, 150)
GOLD = (255, 215, 0)
SILVER = (192, 192, 192)
BRONZE = (205, 127, 50)
SKY_BLUE_LIGHT = (135, 206, 250)

SNAKE_COLORS = [SNAKE_COLOR_BLUE]

# Rutas de recursos 
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
FONTS_DIR = os.path.join(SCRIPT_DIR, "fuentes")
GRAPHICS_DIR = os.path.join(SCRIPT_DIR, "graficos")
SOUNDS_DIR = os.path.join(SCRIPT_DIR, "sonidos")

# Archivos esperados
FONT_SNAKE_CHAN_PATH = os.path.join(FONTS_DIR, "snakechan.ttf")
FONT_SNAKEWAY_PATH = os.path.join(FONTS_DIR, "snake.ttf")
MENU_MUSIC_FILENAME = "menu.mp3"
MENU_MUSIC_PATH = os.path.join(SOUNDS_DIR, MENU_MUSIC_FILENAME)

# Mapeo de sprites (usados para simular el cuerpo y movimiento de la serpiente)
SPRITE_MAP = {
    (0, -1): "head_up.png", 
    (0, 1): "head_down.png",
    (1, 0): "head_right.png",
    (-1, 0): "head_left.png",

    "TAIL_UP": "tail_up.png",
    "TAIL_DOWN": "tail_down.png",
    "TAIL_RIGHT": "tail_right.png",
    "TAIL_LEFT": "tail_left.png",

    "BODY_VERTICAL": "body_vertical.png",
    "BODY_HORIZONTAL": "body_horizontal.png",

    "CORNER_BL": "body_bottomleft.png",
    "CORNER_BR": "body_bottomright.png",
    "CORNER_TL": "body_topleft.png",
    "CORNER_TR": "body_topright.png",

    "FOOD": "apple.png"
}

# Carga de fuentes personalizadas
def load_font(path, size):
    try:
        return pygame.font.Font(path, size)
    except Exception:
        return pygame.font.SysFont("consolas", size)

title_font = load_font(FONT_SNAKE_CHAN_PATH, 80)
leaderboard_title_font = load_font(FONT_SNAKE_CHAN_PATH, 45)
menu_font = load_font(FONT_SNAKEWAY_PATH, 25)
score_font = load_font(FONT_SNAKEWAY_PATH, 25)
input_font = load_font(FONT_SNAKEWAY_PATH, 25)
top3_font = load_font(FONT_SNAKEWAY_PATH, 25)
top3_score_font = load_font(FONT_SNAKEWAY_PATH, 25)
standard_font_score = pygame.font.Font(None, 45)
standard_font_leaderboard = pygame.font.Font(None, 45)

# Carga y escala los sprites
class SpriteManager:
    def __init__(self, cell_size):
        self.cell_size = cell_size
        self.sprites = {}  
        self.food_sprite = None
        self.load_all()

    def load_image(self, filename):
        path = os.path.join(GRAPHICS_DIR, filename)
        if os.path.exists(path):
            try:
                img = pygame.image.load(path).convert_alpha()
                img = pygame.transform.scale(img, (self.cell_size, self.cell_size))
                return img
            except pygame.error as e:
                print(f"Advertencia: no se pudo cargar imagen {path}: {e}")
                return None
        else:
            print(f"Advertencia: sprite no encontrado: {path}")
            return None

    def load_all(self):
        for key, filename in SPRITE_MAP.items():
            if filename:
                surf = self.load_image(filename)
            else:
                surf = None

            if key == "FOOD":
                self.food_sprite = surf
            else:
                self.sprites[key] = surf


FOOD_SIZE_FACTOR = 0.5
food_size = int(cell_size * FOOD_SIZE_FACTOR)
food_offset = (cell_size - food_size) // 2

food_surface = pygame.Surface((cell_size, cell_size), pygame.SRCALPHA)
food_rect = pygame.Rect(food_offset, food_offset, food_size, food_size)
pygame.draw.rect(food_surface, FOOD_COLOR_APPLE_RED, food_rect, 0, 4)

WALL_SIZE_FACTOR = 1.0
wall_size = int(cell_size * WALL_SIZE_FACTOR)
wall_offset = (cell_size - wall_size) // 2

wall_surface = pygame.Surface((cell_size, cell_size), pygame.SRCALPHA)
wall_rect = pygame.Rect(wall_offset, wall_offset, wall_size, wall_size)
pygame.draw.rect(wall_surface, WALL_COLOR_DARK_GREY, wall_rect, 0, 4)

# Sonidos 
eat_sound = None
wall_hit_sound = None
try:
    eat_path = os.path.join(SOUNDS_DIR, "eat.mp3")
    if os.path.exists(eat_path):
        eat_sound = pygame.mixer.Sound(eat_path)
    wall_path = os.path.join(SOUNDS_DIR, "wall.mp3")
    if os.path.exists(wall_path):
        wall_hit_sound = pygame.mixer.Sound(wall_path)
except Exception as e:
    print(f"Advertencia: no se pudieron cargar sonidos: {e}")
    eat_sound = None
    wall_hit_sound = None


# Sonidos de dirección (movimiento de la serpiente)
try:
    move_sounds = {
        "up": pygame.mixer.Sound(os.path.join(SOUNDS_DIR, "up.mp3")),
        "down": pygame.mixer.Sound(os.path.join(SOUNDS_DIR, "down.mp3")),
        "left": pygame.mixer.Sound(os.path.join(SOUNDS_DIR, "left.mp3")),
        "right": pygame.mixer.Sound(os.path.join(SOUNDS_DIR, "right.mp3")),
    }

    for snd in move_sounds.values():
        snd.set_volume(0.4) #ajustar el volumen

except pygame.error as e:
    print(f"Advertencia: Error cargando sonidos de movimiento: {e}")
    move_sounds = {}



def load_menu_music():
    if not pygame.mixer or not pygame.mixer.get_init():
        return
    if not pygame.mixer.music.get_busy():
        if os.path.exists(MENU_MUSIC_PATH):
            try:
                pygame.mixer.music.load(MENU_MUSIC_PATH)
                pygame.mixer.music.play(-1)
            except Exception as e:
                print("Advertencia: no se pudo reproducir menu.mp3:", e)
        else:
            print(f"Advertencia: archivo de música no encontrado: {MENU_MUSIC_PATH}")

def stop_music():
    try:
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()
    except Exception:
        pass

# Manejo de datos
class DataManager:
    def __init__(self, scores_path=os.path.join(BASE_DIR, "data", "global_scores.json"), game_id="SNAKE"):
        self.scores_path = scores_path
        self.game_id = game_id

    def _read_all_data(self):
        if not os.path.exists(self.scores_path):
            return {}

        with open(self.scores_path, 'r', encoding='utf-8') as file:
            try:
                data = json.load(file)
                if not isinstance(data, dict):
                    return {}
                return data
            except json.JSONDecodeError:
                return {}

    def _save_all_data(self, all_data):
        with open(self.scores_path, 'w', encoding='utf-8') as file:
            json.dump(all_data, file, indent=4)

    def load_game_scores(self):
        all_data = self._read_all_data()
        game_scores = all_data.get(self.game_id, [])
        game_scores.sort(key=lambda x: x['score'], reverse=True)
        return game_scores[:10]

    def update_score(self, name, email, score):
        if not email or "@" not in email:
            print("INFO: Puntaje no guardado. Email no válido.")
            return False, 0

        all_data = self._read_all_data()
        if self.game_id not in all_data:
            all_data[self.game_id] = []

        game_scores = all_data[self.game_id]
        prev_top = game_scores[0].copy() if game_scores else None

        record_found = False
        old_score = 0

        for player in game_scores:
            if player.get("email") == email:
                record_found = True
                old_score = player["score"]

                if score > old_score:
                    player["score"] = score
                    player["name"] = name
                    player["date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                else:
                    return False, old_score
                break

        if not record_found:
            game_scores.append({
                "name": name,
                "email": email,
                "score": score,
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })

        game_scores.sort(key=lambda x: x['score'], reverse=True)
        all_data[self.game_id] = game_scores[:10]
        self._save_all_data(all_data)

        new_top = game_scores[0] if game_scores else None

        if new_top and new_top["score"] > 0:
            prev_score = prev_top["score"] if prev_top else 0
            prev_email = prev_top["email"] if prev_top else None

            if new_top["score"] > prev_score or new_top["email"] != prev_email:
                try:
                    if send_email_notification:
                        send_email_notification(
                            recipient_email=new_top["email"],
                            game_name=self.game_id,
                            score=new_top["score"],
                            player_name=new_top["name"]
                        )
                        print(f"Notificación enviada a {new_top['email']} (nuevo récord: {new_top['score']})")
                    else:
                        print("No se pudo enviar notificación (función no disponible).")
                except Exception as e:
                    print(f"Error al enviar notificación: {e}")

        return True, old_score

    def get_top_scores(self):
        return self.load_game_scores()

# Clase para la creacion de muros (aleatorios)
class Wall:
    def __init__(self, snake_body, food_positions, num_walls=15):
        self.positions = []
        self.num_walls = num_walls
        self.generate_initial_pos(snake_body, food_positions)

    def draw(self):
        for position in self.positions:
            wall_rect = pygame.Rect(
                OFFSET + position.x * cell_size,
                OFFSET + position.y * cell_size,
                cell_size,
                cell_size
            )
            screen.blit(wall_surface, wall_rect)

    def generate_random_cell(self):
        return Vector2(random.randint(0, number_of_cells-1), random.randint(0, number_of_cells-1))

    def generate_initial_pos(self, snake_body, food_positions):
        self.positions = []
        excluded = set([(int(v.x), int(v.y)) for v in snake_body] + [(int(p.x), int(p.y)) for p in food_positions])

        for _ in range(self.num_walls):
            pos = self.generate_random_cell()
            while (int(pos.x), int(pos.y)) in excluded:
                pos = self.generate_random_cell()
            self.positions.append(pos)
            excluded.add((int(pos.x), int(pos.y)))

    def regenerate_all_pos(self, snake_body, food_positions):
        self.generate_initial_pos(snake_body, food_positions)

# Clase para la creacion de la comida
class Food:
    def __init__(self, snake_body, num_foods=4):
        self.positions = []
        self.num_foods = num_foods
        self.generate_initial_pos(snake_body)
        # sprite manager's food
        self.sprite = sprite_manager.food_sprite

    def draw(self):
        if self.sprite:
            for position in self.positions:
                rect_pos = pygame.Rect(OFFSET + position.x * cell_size, OFFSET + position.y * cell_size, cell_size, cell_size)
                screen.blit(self.sprite, rect_pos)
        else:
            for position in self.positions:
                pygame.draw.rect(screen, FOOD_COLOR_APPLE_RED,
                                 (OFFSET + position.x * cell_size, OFFSET + position.y * cell_size, cell_size, cell_size), 0, 4)

    def generate_random_cell(self):
        return Vector2(random.randint(0, number_of_cells-1), random.randint(0, number_of_cells-1))

    def generate_initial_pos(self, snake_body):
        self.positions = []
        excluded = set([(int(v.x), int(v.y)) for v in snake_body])
        for _ in range(self.num_foods):
            pos = self.generate_random_cell()
            while (int(pos.x), int(pos.y)) in excluded:
                pos = self.generate_random_cell()
            self.positions.append(pos)
            excluded.add((int(pos.x), int(pos.y)))

    def regenerate_single_pos(self, snake_body):
        excluded = set([(int(v.x), int(v.y)) for v in snake_body] + [(int(p.x), int(p.y)) for p in self.positions])
        pos = self.generate_random_cell()
        while (int(pos.x), int(pos.y)) in excluded:
            pos = self.generate_random_cell()
        self.positions.append(pos)

# Clase usada para la creacion del cuerpo de la serpiente (uso de sprites)
class Snake:
    def __init__(self):
        self.body = [Vector2(6, 9), Vector2(5, 9), Vector2(4, 9)]
        self.direction = Vector2(1, 0)
        self.add_segment = False
        self.eat_sound = eat_sound
        self.wall_hit_sound = wall_hit_sound
        self.can_change_direction = True

        if hasattr(sprite_manager, "snake_sprites"):
            self.sprites = sprite_manager.snake_sprites
        elif hasattr(sprite_manager, "sprites"):
            self.sprites = sprite_manager.sprites
        else:
            raise AttributeError("SpriteManager no tiene ni 'snake_sprites' ni 'sprites'")

    # Serpiente (Dibujado)
    def draw(self):
        for index, block in enumerate(self.body):
            x_pos = int(OFFSET + block.x * cell_size)
            y_pos = int(OFFSET + block.y * cell_size)
            block_rect = pygame.Rect(x_pos, y_pos, cell_size, cell_size)

            # Cabeza
            if index == 0:
                direction = self.body[0] - self.body[1]
                head_sprite = self.sprites.get((int(direction.x), int(direction.y)))
                if head_sprite:
                    screen.blit(head_sprite, block_rect)

            # Cola
            elif index == len(self.body) - 1:
                direction = self.body[-2] - self.body[-1]
                if direction.x == 1:
                    tail_sprite = self.sprites["TAIL_LEFT"]
                elif direction.x == -1:
                    tail_sprite = self.sprites["TAIL_RIGHT"]
                elif direction.y == 1:
                    tail_sprite = self.sprites["TAIL_UP"]
                else:
                    tail_sprite = self.sprites["TAIL_DOWN"]
                if tail_sprite:
                    screen.blit(tail_sprite, block_rect)

            # Cuerpo
            else:
                prev_block = self.body[index + 1] - block
                next_block = self.body[index - 1] - block

                # Linea recta 
                if prev_block.x == next_block.x:
                    body_sprite = self.sprites["BODY_VERTICAL"]
                elif prev_block.y == next_block.y:
                    body_sprite = self.sprites["BODY_HORIZONTAL"]
                else:
                    # Curvas
                    if (prev_block.x == -1 and next_block.y == -1) or (next_block.x == -1 and prev_block.y == -1):
                        body_sprite = self.sprites["CORNER_TL"]  # ↖️
                    elif (prev_block.x == -1 and next_block.y == 1) or (next_block.x == -1 and prev_block.y == 1):
                        body_sprite = self.sprites["CORNER_BL"]  # ↙️
                    elif (prev_block.x == 1 and next_block.y == -1) or (next_block.x == 1 and prev_block.y == -1):
                        body_sprite = self.sprites["CORNER_TR"]  # ↗️
                    elif (prev_block.x == 1 and next_block.y == 1) or (next_block.x == 1 and prev_block.y == 1):
                        body_sprite = self.sprites["CORNER_BR"]  # ↘️
                    else:
                        body_sprite = None
                if body_sprite:
                    screen.blit(body_sprite, block_rect)

    # Movimientos y direccion de la serpiente
    def update(self):
        self.body.insert(0, self.body[0] + self.direction)
        if not self.add_segment:
            self.body = self.body[:-1]
        else:
            self.add_segment = False
        self.can_change_direction = True

    def change_direction(self, new_direction):
       
        if self.can_change_direction and new_direction != -self.direction:
            if new_direction != self.direction:
                if new_direction == Vector2(0, -1) and "up" in move_sounds:
                    move_sounds["up"].play()
                elif new_direction == Vector2(0, 1) and "down" in move_sounds:
                    move_sounds["down"].play()
                elif new_direction == Vector2(-1, 0) and "left" in move_sounds:
                    move_sounds["left"].play()
                elif new_direction == Vector2(1, 0) and "right" in move_sounds:
                    move_sounds["right"].play()

            self.direction = new_direction
            self.can_change_direction = False

    def reset(self):
        self.body = [Vector2(6, 9), Vector2(5, 9), Vector2(4, 9)]
        self.direction = Vector2(1, 0)
        self.can_change_direction = True



# Game
class Game:
    def __init__(self):
        self.snake = Snake()
        self.food = Food(self.snake.body)
        self.wall = Wall(self.snake.body, self.food.positions, num_walls=15)
        self.score = 0
        self.initial_speed_ms = 200
        self.current_speed_ms = self.initial_speed_ms
        self.last_score_wall_update = 0
        self.wall_update_threshold = 10

    def draw(self):
        self.food.draw()
        self.snake.draw()
        self.wall.draw()

    def update(self):
        self.snake.update()
        self.check_collision_with_food()
        self.check_collision_with_edges()
        self.check_collision_with_tail()
        self.check_collision_with_walls()
        self.update_speed()
        self.check_wall_regeneration_by_score()

    def check_collision_with_food(self):
        head = self.snake.body[0]
        for idx, pos in enumerate(self.food.positions):
            if head == pos:
                # comida
                self.food.positions.pop(idx)
                self.snake.add_segment = True
                self.score += 1
                if self.snake.eat_sound:
                    try:
                        self.snake.eat_sound.play()
                    except Exception:
                        pass
                self.food.regenerate_single_pos(self.snake.body)
                self.check_wall_regeneration_by_score(force_check=True)
                return

    def check_collision_with_walls(self):
        head = self.snake.body[0]
        if head in self.wall.positions:
            self.game_over()

    def check_wall_regeneration_by_score(self, force_check=False):
        if force_check and self.score >= self.last_score_wall_update + self.wall_update_threshold:
            self.wall.regenerate_all_pos(self.snake.body, self.food.positions)
            self.last_score_wall_update = self.score

    def check_collision_with_edges(self):
        head = self.snake.body[0]
        if head.x >= number_of_cells or head.x < 0 or head.y >= number_of_cells or head.y < 0:
            self.game_over()

    def check_collision_with_tail(self):
        if self.snake.body[0] in self.snake.body[1:]:
            self.game_over()

    def update_speed(self):
        speed_inc_5 = self.score // 5
        speed_inc_10 = (self.score // 10) * 3
        total_speed_inc = speed_inc_5 + speed_inc_10

        new_speed = max(50, self.initial_speed_ms - total_speed_inc)
        if new_speed != self.current_speed_ms:
            self.current_speed_ms = new_speed
            pygame.time.set_timer(SNAKE_UPDATE, self.current_speed_ms)

    def game_over(self):
        global game_state, last_score, current_player_name, current_player_email
        last_score = self.score

        if self.snake.wall_hit_sound:
            try:
                self.snake.wall_hit_sound.play()
            except Exception:
                pass

        final_name = current_player_name.strip()
        if final_name == "Invitado" or not final_name:
            final_name = current_player_email.split('@')[0] if "@" in current_player_email else "Invitado"

        if last_score > 0:
            data_manager.update_score(final_name[:5], current_player_email, last_score)

        self.snake.reset()
        self.food.generate_initial_pos(self.snake.body)
        self.wall.regenerate_all_pos(self.snake.body, self.food.positions)
        self.score = 0
        self.last_score_wall_update = 0
        game_state = "GAME_OVER"
        stop_music()
        self.current_speed_ms = self.initial_speed_ms
        pygame.time.set_timer(SNAKE_UPDATE, self.current_speed_ms)

# Opciones del Menu
class Button:
    def __init__(self, text, rect, base_color, hover_color, text_color=WHITE, font=menu_font):
        self.text = text
        self.rect = rect
        self.base_color = base_color
        self.hover_color = hover_color
        self.text_color = text_color
        self.font = font

    def draw(self, surface, mouse_pos):
        current_color = self.base_color
        if self.rect.collidepoint(mouse_pos):
            current_color = self.hover_color

        pygame.draw.rect(surface, current_color, self.rect, 0, 10)
        pygame.draw.rect(surface, self.text_color, self.rect, 3, 10)
        text_surf = self.font.render(self.text, True, self.text_color)
        surface.blit(text_surf, text_surf.get_rect(center=self.rect.center))

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

def draw_menu():
    global boton_rects
    screen.fill(SKY_BLUE_LIGHT)
    mouse_pos = pygame.mouse.get_pos()
    clouds = [(ANCHO * 0.2, ALTO * 0.15, 40), (ANCHO * 0.7, ALTO * 0.1, 50), (ANCHO * 0.45, ALTO * 0.2, 30), (ANCHO * 0.1, ALTO * 0.3, 35), (ANCHO * 0.85, ALTO * 0.35, 45)]
    for x, y, size in clouds:
        pygame.draw.circle(screen, WHITE, (int(x), int(y)), size, 0)
        pygame.draw.circle(screen, WHITE, (int(x + size * 0.8), int(y - size * 0.4)), int(size * 0.6), 0)
        pygame.draw.circle(screen, WHITE, (int(x - size * 0.6), int(y + size * 0.2)), int(size * 0.7), 0)
    title_surf = title_font.render("RETRO SNAKE", True, DARK_GREEN)
    screen.blit(title_surf, title_surf.get_rect(center=(ANCHO // 2, ALTO // 4)))
    button_y_start = ALTO // 2 - 50
    button_width = 300
    spacing = 80
    buttons_data = [("JUGAR", button_y_start), ("CLASIFICACIONES", button_y_start + spacing), ("SALIR DEL JUEGO", button_y_start + 2 * spacing)]
    boton_rects = {}
    for text, y in buttons_data:
        rect = pygame.Rect(ANCHO // 2 - button_width // 2, y, button_width, 60)
        Button(text, rect, DARK_GREEN, GREEN_LIGHT_HOVER, WHITE, menu_font).draw(screen, mouse_pos)
        boton_rects[text] = rect
    display_name = current_player_name if current_player_name != "Invitado" else "Invitado (Sin registro)"
    user_surf = score_font.render(f"Jugador: {display_name}", True, DARK_GREEN)
    screen.blit(user_surf, (OFFSET, ALTO - 50))
    load_menu_music()
    return boton_rects

def draw_game_over():
    global game_over_rects
    mouse_pos = pygame.mouse.get_pos()
    overlay = pygame.Surface((ANCHO, ALTO))
    overlay.set_alpha(200)
    overlay.fill(BLACK)
    screen.blit(overlay, (0, 0))
    title_surf = title_font.render("GAME OVER", True, RED)
    try:
        score_display = int(last_score)
    except (TypeError, ValueError):
        score_display = 0
    prefix_surf = menu_font.render("Puntaje: ", True, WHITE)
    score_num_surf = standard_font_leaderboard.render(str(score_display), True, WHITE)
    total_width = prefix_surf.get_width() + score_num_surf.get_width()
    x_start = ANCHO // 2 - total_width // 2
    y_score = ALTO // 3 + 80
    screen.blit(title_surf, title_surf.get_rect(center=(ANCHO // 2, ALTO // 3)))
    screen.blit(prefix_surf, (x_start, y_score - prefix_surf.get_height() // 2))
    screen.blit(score_num_surf, (x_start + prefix_surf.get_width(), y_score - score_num_surf.get_height() // 2))
    if score_display > 0:
        save_msg = score_font.render(f"Puntaje de {current_player_name} registrado.", True, GRAY)
    else:
        save_msg = score_font.render("Intenta conseguir un puntaje mayor a 0.", True, GRAY)
    screen.blit(save_msg, save_msg.get_rect(center=(ANCHO // 2, ALTO // 3 + 120)))
    button_y_start = ALTO // 2 + 100
    button_width = 250
    spacing = 70
    boton_play_again = Button("Volver a Jugar", pygame.Rect(ANCHO // 2 - button_width // 2, button_y_start, button_width, 50), DARK_GREEN, GREEN_LIGHT_HOVER, WHITE, menu_font)
    boton_menu = Button("Ir a Inicio", pygame.Rect(ANCHO // 2 - button_width // 2, button_y_start + spacing, button_width, 50), DARK_GREEN, GREEN_LIGHT_HOVER, WHITE, menu_font)
    boton_main_menu = Button("Menú Principal", pygame.Rect(ANCHO // 2 - button_width // 2, button_y_start + 2 * spacing, button_width, 50), DARK_GREEN, GREEN_LIGHT_HOVER, WHITE, menu_font)
    boton_play_again.draw(screen, mouse_pos)
    boton_menu.draw(screen, mouse_pos)
    boton_main_menu.draw(screen, mouse_pos)
    game_over_rects = {"PLAY_AGAIN": boton_play_again.rect, "MENU": boton_menu.rect, "MAIN_MENU": boton_main_menu.rect}

def draw_name_input_screen():
    global name_input_text, input_box_rect, continue_button_rect, is_input_active
    mouse_pos = pygame.mouse.get_pos()
    box_width = 400
    box_height = 250
    box_rect = pygame.Rect(ANCHO // 2 - box_width // 2, ALTO // 2 - box_height // 2, box_width, box_height)
    draw_menu()
    overlay = pygame.Surface((ANCHO, ALTO))
    overlay.set_alpha(150)
    overlay.fill(BLACK)
    screen.blit(overlay, (0, 0))
    pygame.draw.rect(screen, DARK_GREEN, box_rect, 0, 10)
    pygame.draw.rect(screen, DARK_GREEN, box_rect, 5, 10)
    title_surf = menu_font.render("¡INGRESA TU NOMBRE!", True, WHITE)
    screen.blit(title_surf, title_surf.get_rect(center=(ANCHO // 2, box_rect.y + 40)))
    input_box_rect = pygame.Rect(ANCHO // 2 - 150, box_rect.y + 90, 300, 40)
    pygame.draw.rect(screen, WHITE, input_box_rect, 0, 5)
    pygame.draw.rect(screen, DARK_GREEN, input_box_rect, 2, 5)
    display_text = name_input_text if name_input_text else "Tu nombre (Máx 5)"
    text_color = BLACK if name_input_text else GRAY
    text_surf = input_font.render(display_text, True, text_color)
    screen.blit(text_surf, (input_box_rect.x + 10, input_box_rect.y + 8))
    if is_input_active and pygame.time.get_ticks() % 1000 < 500:
        cursor_x = input_box_rect.x + 10 + input_font.size(name_input_text)[0]
        pygame.draw.line(screen, BLACK, (cursor_x, input_box_rect.y + 8), (cursor_x, input_box_rect.y + 32), 2)
    continue_button = Button("CONTINUAR", pygame.Rect(ANCHO // 2 - 100, box_rect.y + 160, 200, 50), DARK_GREEN, GREEN_LIGHT_HOVER, WHITE, menu_font)
    continue_button.draw(screen, mouse_pos)
    continue_button_rect = continue_button.rect
    return input_box_rect, continue_button_rect

def draw_leaderboard():
    global leaderboard_rects
    screen.fill(SKY_BLUE_LIGHT)
    mouse_pos = pygame.mouse.get_pos()
    title_surf = leaderboard_title_font.render("CLASIFICACIONES TOP 10", True, DARK_GREEN)
    screen.blit(title_surf, title_surf.get_rect(center=(ANCHO // 2, 40)))
    top_scores = data_manager.get_top_scores()
    displayed_scores = top_scores[:10]
    if not displayed_scores:
        no_scores_surf = menu_font.render("¡Sé el primero en el ranking!", True, DARK_GREEN)
        screen.blit(no_scores_surf, no_scores_surf.get_rect(center=(ANCHO // 2, ALTO // 2)))
    MEDALS = [GOLD, SILVER, BRONZE]
    rank_y_start = 120
    rank_height = 80
    for i in range(min(3, len(displayed_scores))):
        player = displayed_scores[i]
        rank_rect = pygame.Rect(OFFSET + 10, rank_y_start + i * rank_height, ANCHO - 2 * OFFSET - 20, rank_height - 10)
        pygame.draw.rect(screen, MEDALS[i], rank_rect, 0, 8)
        pygame.draw.rect(screen, DARK_GREEN, rank_rect, 3, 8)
        rank_text = top3_font.render(f"{i + 1}°", True, DARK_GREEN)
        screen.blit(rank_text, (OFFSET + 30, rank_rect.centery - rank_text.get_height() // 2))
        name_text = top3_score_font.render(player['name'][:5], True, DARK_GREEN)
        screen.blit(name_text, (OFFSET + 120, rank_rect.centery - name_text.get_height() // 2))
        score_text = standard_font_leaderboard.render(str(player['score']), True, DARK_GREEN)
        screen.blit(score_text, (ANCHO - OFFSET - score_text.get_width() - 30, rank_rect.centery - score_text.get_height() // 2))
    table_y_start = rank_y_start + min(3, len(displayed_scores)) * rank_height + 10
    if len(displayed_scores) > 3:
        header_font = menu_font
        row_font = score_font
        col_x = [OFFSET + 20, OFFSET + 120, ANCHO - OFFSET - 150]
        screen.blit(header_font.render("Puesto", True, DARK_GREEN), (col_x[0], table_y_start))
        screen.blit(header_font.render("Nombre", True, DARK_GREEN), (col_x[1], table_y_start))
        screen.blit(header_font.render("Puntaje", True, DARK_GREEN), (col_x[2], table_y_start))
        for i, player in enumerate(displayed_scores[3:]):
            rank = i + 4
            y = table_y_start + 40 + i * 35
            screen.blit(row_font.render(f"{rank}°", True, DARK_GREEN), (col_x[0], y))
            screen.blit(row_font.render(player['name'][:5], True, DARK_GREEN), (col_x[1], y))
            screen.blit(standard_font_score.render(str(player['score']), True, DARK_GREEN), (col_x[2], y))
    button_width = 200
    btn_y = ALTO - 60
    menu_btn = Button("Menú", pygame.Rect((ANCHO - button_width) // 2, btn_y, button_width, 50), DARK_GREEN, GREEN_LIGHT_HOVER, WHITE, menu_font)
    menu_btn.draw(screen, mouse_pos)
    leaderboard_rects = {"MENU": menu_btn.rect}

# Bucle principal y estados ----------------------
SNAKE_UPDATE = pygame.USEREVENT
input_box_rect = pygame.Rect(0, 0, 0, 0)
continue_button_rect = pygame.Rect(0, 0, 0, 0)
is_input_active = False

# estados globales 
GLOBAL_SCORES_PATH = os.path.join(BASE_DIR, "data", "global_scores.json")
GAME_IDENTIFIER = "SNAKE"
game_state = "MENU"
current_player_name = "Invitado"
current_player_email = ""
last_score = 0
name_input_text = ""

screen = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Retro Snake Plus")
clock = pygame.time.Clock()


sprite_manager = SpriteManager(cell_size)


data_manager = None
game = None

def start_game_loop(player_name_arg, player_email_arg):
    global data_manager, game, current_player_name, current_player_email, game_state, last_score, name_input_text, is_input_active, input_box_rect, continue_button_rect

    data_manager = DataManager()
    game = Game()

    current_player_name = player_name_arg
    current_player_email = player_email_arg

    pygame.time.set_timer(SNAKE_UPDATE, game.current_speed_ms)

    if current_player_name != "Invitado":
        name_input_text = current_player_name[:5]

    if current_player_email and "@" in current_player_email:
        game_state = "NAME_INPUT_MENU"

    load_menu_music()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if game_state == "NAME_INPUT_MENU":
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = event.pos

                    if input_box_rect.collidepoint(mouse_pos):
                        is_input_active = True
                    else:
                        is_input_active = False

                    if continue_button_rect.collidepoint(mouse_pos):
                        if name_input_text.strip():
                            current_player_name = name_input_text.strip()[:5]
                        else:
                            current_player_name = (current_player_email.split('@')[0] if "@" in current_player_email else "Invitado")[:5]
                        game_state = "RUNNING"
                        stop_music()

                elif event.type == pygame.KEYDOWN and is_input_active:
                    if event.key == pygame.K_RETURN:
                        if name_input_text.strip():
                            current_player_name = name_input_text.strip()[:5]
                        else:
                            current_player_name = (current_player_email.split('@')[0] if "@" in current_player_email else "Invitado")[:5]
                        game_state = "RUNNING"
                        stop_music()

                    elif event.key == pygame.K_BACKSPACE:
                        name_input_text = name_input_text[:-1]
                    else:
                        if len(name_input_text) < 5 and (event.unicode.isalnum() or event.unicode.isspace()):
                            name_input_text += event.unicode
                continue

            if game_state == "RUNNING":
                if event.type == SNAKE_UPDATE:
                    game.update()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP: game.snake.change_direction(Vector2(0, -1))
                    if event.key == pygame.K_DOWN: game.snake.change_direction(Vector2(0, 1))
                    if event.key == pygame.K_LEFT: game.snake.change_direction(Vector2(-1, 0))
                    if event.key == pygame.K_RIGHT: game.snake.change_direction(Vector2(1, 0))

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos
                if game_state == "MENU":
                    if boton_rects["JUGAR"].collidepoint(mouse_pos):
                        if current_player_email and "@" in current_player_email:
                            game_state = "NAME_INPUT_MENU"
                        else:
                            game_state = "RUNNING"
                        stop_music()
                    elif boton_rects["CLASIFICACIONES"].collidepoint(mouse_pos):
                        game_state = "LEADERBOARD"
                    elif boton_rects["SALIR DEL JUEGO"].collidepoint(mouse_pos):
                        pygame.quit()
                        sys.exit()
                elif game_state == "GAME_OVER":
                    if game_over_rects["PLAY_AGAIN"].collidepoint(mouse_pos):
                        if current_player_email and "@" in current_player_email:
                            game_state = "NAME_INPUT_MENU"
                        else:
                            game_state = "RUNNING"
                        stop_music()
                    elif game_over_rects["MENU"].collidepoint(mouse_pos):
                        game_state = "MENU"
                        load_menu_music()
                    elif game_over_rects["MAIN_MENU"].collidepoint(mouse_pos):
                        pygame.quit()
                        sys.exit()
                elif game_state == "LEADERBOARD":
                    if leaderboard_rects["MENU"].collidepoint(mouse_pos):
                        game_state = "MENU"
                        load_menu_music()

        # DIBUJO
        if game_state == "MENU":
            draw_menu()
        elif game_state == "NAME_INPUT_MENU":
            input_box_rect, continue_button_rect = draw_name_input_screen()
        elif game_state in ("RUNNING", "GAME_OVER"):
            screen.fill(DARK_GREEN)
            # grid
            for fila in range(number_of_cells):
                for col in range(number_of_cells):
                    cell_color = GRID_DARK if (fila + col) % 2 == 0 else GRID_LIGHT
                    pygame.draw.rect(screen, cell_color, (OFFSET + col * cell_size, OFFSET + fila * cell_size, cell_size, cell_size))

            pygame.draw.rect(screen, DARK_GREEN, (OFFSET - 5, OFFSET - 5, cell_size * number_of_cells + 10, cell_size * number_of_cells + 10), 5)
            game.draw()

            
            display_name = current_player_name if current_player_name != "Invitado" else "Invitado"

            # Texto del jugador (izquierda)
            name_surf = score_font.render(f"Jugador: {display_name}", True, WHITE)
            screen.blit(name_surf, (OFFSET, OFFSET - 40))

            # Ícono de manzana + puntaje (derecha)
            apple_icon = sprite_manager.food_sprite
            if apple_icon:
                apple_icon_scaled = pygame.transform.scale(apple_icon, (30, 30))
                apple_x = ANCHO - OFFSET - 100  # posición base del ícono
                apple_y = OFFSET - 45
                screen.blit(apple_icon_scaled, (apple_x, apple_y))
            else:
                pygame.draw.rect(screen, FOOD_COLOR_APPLE_RED, (ANCHO - OFFSET - 100, OFFSET - 45, 30, 30), 0, 5)

            # Número del puntaje
            score_surf = standard_font_score.render(str(game.score), True, WHITE)
            screen.blit(score_surf, (ANCHO - OFFSET - 60, OFFSET - 41))


            if game_state == "GAME_OVER":
                draw_game_over()
        elif game_state == "LEADERBOARD":
            draw_leaderboard()

        pygame.display.update()
        clock.tick(60)

if __name__ == '__main__':
    initial_email = sys.argv[1] if len(sys.argv) > 1 else ""
    player_name = initial_email.split('@')[0] if initial_email and "@" in initial_email else "Invitado"

    font_dirs = [os.path.dirname(FONT_SNAKE_CHAN_PATH), os.path.dirname(FONT_SNAKEWAY_PATH)]
    for f_dir in font_dirs:
        if f_dir and f_dir not in sys.path:
            sys.path.insert(0, f_dir)

    start_game_loop(player_name, initial_email)
