import pygame
import sys
import random
import os

# ===============================
# CONFIGURACIÓN INICIAL
# ===============================
pygame.init()

# Inicialización robusta del mezclador
try:
    pygame.mixer.quit()
    pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
except Exception as e:
    print(f"Advertencia: error al iniciar el mezclador de sonido ({e})")
    pygame.mixer = None

WIDTH, HEIGHT = 800, 625
FPS = 60

WHITE = (255, 255, 255)
DARK_GRAY = (34, 34, 34)
RED = (200, 50, 50)

PADDLE_WIDTH, PADDLE_HEIGHT = 15, 125
BALL_SIZE = 15

VELOCITY = 12
BALL_VEL_X = 10
BALL_VEL_Y = 10

# ===============================
# CARGA DE RECURSOS
# ===============================
BASE_DIR = os.path.dirname(os.path.abspath(__file__)) if '__file__' in locals() else os.getcwd()

def load_sound(filename):
    """Carga un sonido de forma segura."""
    path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(path):
        return None
    try:
        if pygame.mixer is not None:
            return pygame.mixer.Sound(path)
        return None
    except Exception as e:
        print(f"No se pudo cargar el sonido {filename}: {e}")
        return None

# Cargar sonidos
paddle_sound = load_sound("paddle.mp3")
score_sound = load_sound("score.mp3")
wall_sound = load_sound("wall.mp3")

# Fuentes
try:
    font = pygame.font.Font(None, 32)
    big_font = pygame.font.Font(None, 48)
    instr_font = pygame.font.Font(None, 24)
except pygame.error:
    print("Advertencia: No se pudo cargar la fuente del sistema.")
    font = big_font = instr_font = None


# ===============================
# FUNCIÓN SEGURA PARA REPRODUCIR SONIDOS
# ===============================
def safe_play(sound):
    """Reproduce un sonido sin bloquear el juego."""
    try:
        if sound and pygame.mixer is not None:
            sound.play()
    except Exception:
        pass


# ===============================
# FUNCIÓN PARA DIBUJAR BOTONES CON HOVER
# ===============================
def draw_button(screen, text, x, y, width, height):
    mouse_pos = pygame.mouse.get_pos()
    rect = pygame.Rect(x, y, width, height)

    # Hover: color rojo y ligero escalado
    hover_scale = 1.05
    if rect.collidepoint(mouse_pos):
        rect = pygame.Rect(
            x - width * (hover_scale - 1)/2,
            y - height * (hover_scale - 1)/2,
            width * hover_scale,
            height * hover_scale
        )
        color = RED
    else:
        color = WHITE

    pygame.draw.rect(screen, color, rect, border_radius=12)

    # Texto
    button_text = big_font.render(text, True, DARK_GRAY)
    text_x = rect.x + (rect.width - button_text.get_width()) // 2
    text_y = rect.y + (rect.height - button_text.get_height()) // 2
    screen.blit(button_text, (text_x, text_y))

    return rect


# ===============================
# CLASE PRINCIPAL DEL JUEGO
# ===============================
class PongGame:
    def __init__(self):
        self.game_state = "RUNNING"  # "RUNNING", "PAUSED", "MENU"
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Pong - 2 Players")
        self.clock = pygame.time.Clock()
        self.reset_game()
        self.menu_button_rect = None
        self.display_instructions = True

    def reset_game(self):
        self.p1_y = (HEIGHT - PADDLE_HEIGHT) // 2
        self.p2_y = (HEIGHT - PADDLE_HEIGHT) // 2
        self.p1_vel = 0
        self.p2_vel = 0
        self.ball_x = WIDTH // 2
        self.ball_y = HEIGHT // 2
        self.ball_vel_x = BALL_VEL_X * random.choice([-1, 1])
        self.ball_vel_y = BALL_VEL_Y * random.choice([-1, 1])
        self.score = [0, 0]
        self.cooldown = 60
        self.display_instructions = False

    # ===============================
    # DIBUJADO
    # ===============================
    def draw(self):
        self.screen.fill(DARK_GRAY)

        # Paletas y pelota
        pygame.draw.rect(self.screen, WHITE, (35, self.p1_y, PADDLE_WIDTH, PADDLE_HEIGHT))
        pygame.draw.rect(self.screen, WHITE, (WIDTH - 35 - PADDLE_WIDTH, self.p2_y, PADDLE_WIDTH, PADDLE_HEIGHT))
        pygame.draw.rect(self.screen, WHITE, (self.ball_x, self.ball_y, BALL_SIZE, BALL_SIZE))

        # Línea central
        for y in range(0, HEIGHT, 30):
            pygame.draw.line(self.screen, WHITE, (WIDTH // 2, y), (WIDTH // 2, y + 15), 3)

        # Marcador
        if font and big_font and instr_font:
            score_text = font.render(f"{self.score[0]}    {self.score[1]}", True, WHITE)
            self.screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, 35))

            # Texto de controles e info
            if self.game_state == "RUNNING":
                # ✅ Instrucción reposicionada en esquina superior derecha
                info_text = font.render("[P] Pausar", True, WHITE)
                self.screen.blit(info_text, (WIDTH - info_text.get_width() - 20, 20))

                # Instrucciones iniciales
                if self.display_instructions:
                    p1_instr = instr_font.render("JUGADOR 1: [W] [S]", True, WHITE)
                    p2_instr = instr_font.render("JUGADOR 2: [↑] [↓]", True, WHITE)
                    self.screen.blit(p1_instr, (50, HEIGHT - 35))
                    self.screen.blit(p2_instr, (WIDTH - 50 - p2_instr.get_width(), HEIGHT - 35))

            # Pantalla de pausa
            if self.game_state == "PAUSED":
                pause_text = font.render("PAUSA [P]", True, WHITE)
                self.screen.blit(pause_text, (WIDTH // 2 - pause_text.get_width() // 2, HEIGHT // 2 - 50))

                self.menu_button_rect = draw_button(self.screen, "MENÚ PRINCIPAL", WIDTH//2-150, HEIGHT//2+10, 300, 60)

            elif self.game_state == "RUNNING":
                self.menu_button_rect = None

        pygame.display.flip()

    # ===============================
    # ACTUALIZACIÓN DEL JUEGO
    # ===============================
    def update(self):
        keys = pygame.key.get_pressed()

        # Movimiento Jugador 1 (W/S)
        self.p1_vel = 0
        if keys[pygame.K_w]:
            self.p1_vel = -VELOCITY
        elif keys[pygame.K_s]:
            self.p1_vel = VELOCITY

        # Movimiento Jugador 2 (Flechas)
        self.p2_vel = 0
        if keys[pygame.K_UP]:
            self.p2_vel = -VELOCITY
        elif keys[pygame.K_DOWN]:
            self.p2_vel = VELOCITY

        # Ocultar instrucciones al moverse
        if self.display_instructions and (self.p1_vel != 0 or self.p2_vel != 0):
            self.display_instructions = False

        # Aplicar movimiento
        self.p1_y = max(0, min(HEIGHT - PADDLE_HEIGHT, self.p1_y + self.p1_vel))
        self.p2_y = max(0, min(HEIGHT - PADDLE_HEIGHT, self.p2_y + self.p2_vel))

        # Enfriamiento inicial
        if self.cooldown > 0:
            self.cooldown -= 1
            return

        # Movimiento de pelota
        self.ball_x += self.ball_vel_x
        self.ball_y += self.ball_vel_y

        # Rebote en paredes
        if self.ball_y <= 0 or self.ball_y + BALL_SIZE >= HEIGHT:
            self.ball_vel_y *= -1
            safe_play(wall_sound)

        # Gol
        if self.ball_x <= 0:
            self.score[1] += 1
            self.reset_ball("p2")
        elif self.ball_x + BALL_SIZE >= WIDTH:
            self.score[0] += 1
            self.reset_ball("p1")

        # Colisiones con paletas
        ball_rect = pygame.Rect(self.ball_x, self.ball_y, BALL_SIZE, BALL_SIZE)
        p1_rect = pygame.Rect(35, self.p1_y, PADDLE_WIDTH, PADDLE_HEIGHT)
        p2_rect = pygame.Rect(WIDTH - 35 - PADDLE_WIDTH, self.p2_y, PADDLE_WIDTH, PADDLE_HEIGHT)

        if ball_rect.colliderect(p1_rect) and self.ball_vel_x < 0:
            self.ball_x = 35 + PADDLE_WIDTH
            offset = (self.ball_y + BALL_SIZE / 2) - (self.p1_y + PADDLE_HEIGHT / 2)
            self.ball_vel_y = offset * 0.3
            self.ball_vel_x *= -1
            safe_play(paddle_sound)

        elif ball_rect.colliderect(p2_rect) and self.ball_vel_x > 0:
            self.ball_x = WIDTH - 35 - PADDLE_WIDTH - BALL_SIZE
            offset = (self.ball_y + BALL_SIZE / 2) - (self.p2_y + PADDLE_HEIGHT / 2)
            self.ball_vel_y = offset * 0.3
            self.ball_vel_x *= -1
            safe_play(paddle_sound)

    # ===============================
    # REINICIO DE PELOTA
    # ===============================
    def reset_ball(self, scorer):
        self.ball_x = WIDTH // 2
        self.ball_y = HEIGHT // 2
        self.ball_vel_x = BALL_VEL_X * (-1 if scorer == "p2" else 1)
        self.ball_vel_y = BALL_VEL_Y * random.choice([-1, 1])
        self.cooldown = 60
        safe_play(score_sound)

    # ===============================
    # BUCLE PRINCIPAL
    # ===============================
    def run(self):
        running = True
        while running:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    self.game_state = False

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        if self.game_state == "RUNNING":
                            self.game_state = "PAUSED"
                        elif self.game_state == "PAUSED":
                            self.game_state = "RUNNING"
                    elif event.key == pygame.K_RETURN and self.menu_button_rect:
                        # Enter en pausa = volver al menú
                        self.game_state = "MENU"
                        running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.game_state == "PAUSED" and self.menu_button_rect:
                        if self.menu_button_rect.collidepoint(event.pos):
                            self.game_state = "MENU"
                            running = False

            if self.game_state == "RUNNING":
                self.update()

            self.draw()

        # No hacemos pygame.quit() aquí para no cerrar el menú
        return self.game_state


# ===============================
# FUNCIÓN DE INICIO
# ===============================
def run_multiplayer():
    final_state = PongGame().run()
    return final_state


# ===============================
# EJECUCIÓN DIRECTA
# ===============================
if __name__ == "__main__":
    run_multiplayer()
    sys.exit()
