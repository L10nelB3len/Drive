import pygame
import sys
import os


# importamos los modos de juego 1player 2players

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(BASE_DIR, "singleplayer"))
sys.path.append(os.path.join(BASE_DIR, "multiplayer"))

from single_player import run_singleplayer
from two_player import run_multiplayer


# Configuracion de pantalla y colores


pygame.init()
WIDTH, HEIGHT = 800, 625
WHITE = (255, 255, 255)
DARK_GRAY = (34, 34, 34)
RED = (200, 50, 50)
LIGHT_RED = (255, 100, 100)
FPS = 60

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pong - Menú Principal")
clock = pygame.time.Clock()


# Fuentes personalizadas


try:
    title_font = pygame.font.Font(os.path.join(BASE_DIR, "MyGirlIsRetro-0Grz.ttf"), 120) #usado en titulo: "Pong"
except:
    title_font = pygame.font.Font(None, 120)

try:
    button_font = pygame.font.Font(os.path.join(BASE_DIR, "bit5x3.ttf"), 40) #usado en: botones
except:
    button_font = pygame.font.Font(None, 40)


# Botones y navegacion


menu_options = ["1 PLAYER", "2 PLAYERS", "SALIR"]
selected_index = 0  


def draw_button(text, x, y, width, height, is_selected, is_hovered):
   
    rect = pygame.Rect(x, y, width, height)

    if is_selected:
        color = LIGHT_RED
    elif is_hovered:
        color = RED
    else:
        color = WHITE

    pygame.draw.rect(screen, color, rect, border_radius=12)
    text_surface = button_font.render(text, True, DARK_GRAY)
    text_x = x + (width - text_surface.get_width()) // 2
    text_y = y + (height - text_surface.get_height()) // 2
    screen.blit(text_surface, (text_x, text_y))

    return rect



# MENÚ
def main_menu():
    global selected_index
    running = True

    button_width, button_height = 250, 70
    start_y = 250
    spacing = 90

    while running:
        screen.fill(DARK_GRAY)
        mouse_pos = pygame.mouse.get_pos()

      
        # Titulo del programa
        title_surface = title_font.render("PONG", True, WHITE)
        title_rect = title_surface.get_rect(center=(WIDTH // 2, 130))
        screen.blit(title_surface, title_rect)

       
        # Botones
        button_rects = []
        for i, option in enumerate(menu_options):
            x = WIDTH // 2 - button_width // 2
            y = start_y + i * spacing

            is_hovered = pygame.Rect(x, y, button_width, button_height).collidepoint(mouse_pos)
            is_selected = (i == selected_index)
            rect = draw_button(option, x, y, button_width, button_height, is_selected, is_hovered)
            button_rects.append(rect)


        # Eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_w, pygame.K_UP]:
                    selected_index = (selected_index - 1) % len(menu_options)
                elif event.key in [pygame.K_s, pygame.K_DOWN]:
                    selected_index = (selected_index + 1) % len(menu_options)
                elif event.key == pygame.K_RETURN:
                    option = menu_options[selected_index]
                    if option == "1 PLAYER":
                        state = run_singleplayer()
                        if state == "MENU":
                            continue
                    elif option == "2 PLAYERS":
                        state = run_multiplayer()
                        if state == "MENU":
                            continue
                    elif option == "SALIR":
                        pygame.quit()
                        sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                for i, rect in enumerate(button_rects):
                    if rect.collidepoint(event.pos):
                        option = menu_options[i]
                        if option == "1 PLAYER":
                            state = run_singleplayer()
                            if state == "MENU":
                                continue
                        elif option == "2 PLAYERS":
                            state = run_multiplayer()
                            if state == "MENU":
                                continue
                        elif option == "SALIR":
                            pygame.quit()
                            sys.exit()

        
        pygame.display.flip()
        clock.tick(FPS)


if __name__ == "__main__":
    main_menu()
