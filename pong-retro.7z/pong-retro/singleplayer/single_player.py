import pygame
import sys
import random
import os

# ===============================
# CONFIGURACIÓN INICIAL
# ===============================
pygame.init()

# Inicialización robusta del mezclador
try:
    pygame.mixer.quit()
    pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
except Exception as e:
    print(f"Advertencia: error al iniciar el mezclador de sonido ({e})")
    pygame.mixer = None

WIDTH, HEIGHT = 800, 625
FPS = 60

# Colores
WHITE = (255, 255, 255)
DARK_BG = (0, 0, 0)
RED = (200, 50, 50)

# Paredes
WALL_THICKNESS = 10

# Paletas y pelota
PADDLE_WIDTH, PADDLE_HEIGHT = 15, 125
BALL_SIZE = 15

VELOCITY = 12
BALL_VEL_X = 10
BALL_VEL_Y = 10

# ===============================
# CARGA DE RECURSOS
# ===============================
BASE_DIR = os.path.dirname(os.path.abspath(__file__)) if '__file__' in locals() else os.getcwd()

def load_sound(filename):
    path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(path):
        return None
    try:
        if pygame.mixer is not None:
            return pygame.mixer.Sound(path)
        return None
    except Exception as e:
        print(f"No se pudo cargar el sonido {filename}: {e}")
        return None

paddle_sound = load_sound("paddle.mp3")
score_sound = load_sound("score.mp3")
wall_sound = load_sound("wall.mp3")

try:
    font = pygame.font.Font(None, 32)
    big_font = pygame.font.Font(None, 48)
    instr_font = pygame.font.Font(None, 24)
except pygame.error:
    print("Advertencia: No se pudo cargar la fuente del sistema.")
    font = big_font = instr_font = None

# ===============================
# FUNCIONES AUXILIARES
# ===============================
def safe_play(sound):
    try:
        if sound and pygame.mixer is not None:
            sound.play()
    except Exception:
        pass

def draw_hover_button(screen, text, x, y, width, height):
    mouse_pos = pygame.mouse.get_pos()
    rect = pygame.Rect(x, y, width, height)
    hover_scale = 1.05

    if rect.collidepoint(mouse_pos):
        rect = pygame.Rect(
            x - width * (hover_scale - 1)/2,
            y - height * (hover_scale - 1)/2,
            width * hover_scale,
            height * hover_scale
        )
        color = RED
    else:
        color = WHITE

    pygame.draw.rect(screen, color, rect, border_radius=12)
    button_text = big_font.render(text, True, DARK_BG)
    text_x = rect.x + (rect.width - button_text.get_width()) // 2
    text_y = rect.y + (rect.height - button_text.get_height()) // 2
    screen.blit(button_text, (text_x, text_y))

    return rect

# ===============================
# CLASE PRINCIPAL DEL JUEGO
# ===============================
class PongGame:
    def __init__(self):
        self.game_state = "RUNNING"
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Pong - 1 Player")
        self.clock = pygame.time.Clock()
        self.reset_game()
        self.menu_button_rect = None
        self.restart_button_rect = None
        self.display_instructions = True
        self.max_score = 10
        self.winner = None

    def reset_game(self):
        self.player_y = (HEIGHT - PADDLE_HEIGHT) // 2
        self.ai_y = (HEIGHT - PADDLE_HEIGHT) // 2
        self.player_vel = 0
        self.ai_vel = 0
        self.ball_x = WIDTH // 2
        self.ball_y = HEIGHT // 2
        self.ball_vel_x = BALL_VEL_X * random.choice([-1, 1])
        self.ball_vel_y = BALL_VEL_Y * random.choice([-1, 1])
        self.score = [0, 0]
        self.cooldown = 60
        self.optimal_position = (HEIGHT - PADDLE_HEIGHT) // 2
        self.display_instructions = True
        self.winner = None

    # ===============================
    # IA CON DIFICULTAD MEDIA-BAJA
    # ===============================
    def calculate_ai_target(self):
        if self.ball_vel_x < 0:
            return self.ai_y

        bx, by = self.ball_x, self.ball_y
        vx, vy = self.ball_vel_x, self.ball_vel_y

        while bx < WIDTH - 35 - PADDLE_WIDTH:
            bx += vx
            by += vy
            if by <= WALL_THICKNESS or by + BALL_SIZE >= HEIGHT - WALL_THICKNESS:
                vy *= -1

        target_center = by + BALL_SIZE / 2
        target_y = target_center - PADDLE_HEIGHT / 2

        # Mayor probabilidad de error
        if random.randint(0, 100) <= 70:
            target_y += random.choice([-60, -40, -20, 0, 20, 40, 60])

        return max(WALL_THICKNESS, min(HEIGHT - WALL_THICKNESS - PADDLE_HEIGHT, target_y))

    def reset_ball(self, scoring_player):
        self.ball_x = WIDTH // 2
        self.ball_y = HEIGHT // 2
        self.ball_vel_x = BALL_VEL_X * (-1 if scoring_player == "ai" else 1)
        self.ball_vel_y = BALL_VEL_Y * random.choice([-1, 1])
        self.optimal_position = self.calculate_ai_target()
        self.cooldown = 60
        safe_play(score_sound)
        self.display_instructions = False

    # ===============================
    # DIBUJADO
    # ===============================
    def draw(self):
        self.screen.fill(DARK_BG)

        # Paredes superior e inferior
        pygame.draw.rect(self.screen, WHITE, (0, 0, WIDTH, WALL_THICKNESS))
        pygame.draw.rect(self.screen, WHITE, (0, HEIGHT - WALL_THICKNESS, WIDTH, WALL_THICKNESS))

        # Paletas y pelota
        pygame.draw.rect(self.screen, WHITE, (35, self.player_y, PADDLE_WIDTH, PADDLE_HEIGHT))
        pygame.draw.rect(self.screen, WHITE, (WIDTH - 35 - PADDLE_WIDTH, self.ai_y, PADDLE_WIDTH, PADDLE_HEIGHT))
        pygame.draw.rect(self.screen, WHITE, (self.ball_x, self.ball_y, BALL_SIZE, BALL_SIZE))

        # Línea central
        for y in range(0, HEIGHT, 30):
            pygame.draw.line(self.screen, WHITE, (WIDTH // 2, y), (WIDTH // 2, y + 15), 3)

        # Marcador
        if font and big_font and instr_font:
            score_text = font.render(f"{self.score[0]}    {self.score[1]}", True, WHITE)
            self.screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, 35))

            # Pausa en la esquina superior derecha
            if self.game_state == "RUNNING" and not self.display_instructions:
                info_text = font.render("[P] Pausar", True, WHITE)
                self.screen.blit(info_text, (WIDTH - info_text.get_width() - 20, 20))

            # Instrucciones iniciales
            if self.display_instructions and self.game_state == "RUNNING":
                player_instr = instr_font.render("JUGADOR: [W] [S]", True, WHITE)
                ai_instr = instr_font.render("OPONENTE: CPU", True, WHITE)
                self.screen.blit(player_instr, (50, HEIGHT - 35))
                self.screen.blit(ai_instr, (WIDTH - 50 - ai_instr.get_width(), HEIGHT - 35))

            # Pausa y botón de menú
            if self.game_state == "PAUSED":
                pause_text = font.render("PAUSA [P]", True, WHITE)
                self.screen.blit(pause_text, (WIDTH // 2 - pause_text.get_width() // 2, 20))
                self.menu_button_rect = draw_hover_button(self.screen, "MENÚ PRINCIPAL",
                                                          WIDTH//2-150, HEIGHT//2+10, 300, 60)
            elif self.game_state == "GAME_OVER":
                if self.winner == "player":
                    result_text = big_font.render("GANASTE!", True, WHITE)
                else:
                    result_text = big_font.render("GAME OVER", True, WHITE)
                self.screen.blit(result_text, (WIDTH//2 - result_text.get_width()//2, HEIGHT//2 - 100))

                self.menu_button_rect = draw_hover_button(self.screen, "MENÚ PRINCIPAL",
                                                          WIDTH//2-150, HEIGHT//2, 300, 60)
                self.restart_button_rect = draw_hover_button(self.screen, "VOLVER A JUGAR",
                                                             WIDTH//2-150, HEIGHT//2 + 80, 300, 60)
            else:
                self.menu_button_rect = None

        pygame.display.flip()

    # ===============================
    # ACTUALIZACIÓN DEL JUEGO
    # ===============================
    def update(self):
        keys = pygame.key.get_pressed()
        self.player_vel = -VELOCITY if keys[pygame.K_w] else VELOCITY if keys[pygame.K_s] else 0

        if self.display_instructions and self.player_vel != 0:
            self.display_instructions = False

        self.player_y = max(WALL_THICKNESS, min(HEIGHT - WALL_THICKNESS - PADDLE_HEIGHT, self.player_y + self.player_vel))

        # Movimiento IA más lento y menos preciso
        if self.ball_vel_x > 0 and self.ball_x > WIDTH * 0.25:
            if abs(self.ai_y - self.optimal_position) > 25:
                self.ai_vel = VELOCITY * 0.5 if self.ai_y < self.optimal_position else -VELOCITY * 0.5
            elif abs(self.ai_y - self.optimal_position) > 2:
                self.ai_vel = 0.3 * VELOCITY if self.ai_y < self.optimal_position else -0.3 * VELOCITY
            else:
                self.ai_vel = 0
        else:
            target_center = (HEIGHT - PADDLE_HEIGHT) // 2
            self.ai_vel = 0.3 * VELOCITY if self.ai_y < target_center else -0.3 * VELOCITY if abs(self.ai_y - target_center) > 1 else 0

        self.ai_y = max(WALL_THICKNESS, min(HEIGHT - WALL_THICKNESS - PADDLE_HEIGHT, self.ai_y + self.ai_vel))

        if self.cooldown > 0:
            self.cooldown -= 1
            return

        # Movimiento de la pelota
        self.ball_x += self.ball_vel_x
        self.ball_y += self.ball_vel_y

        # Rebote con paredes
        if self.ball_y <= WALL_THICKNESS or self.ball_y + BALL_SIZE >= HEIGHT - WALL_THICKNESS:
            self.ball_vel_y *= -1
            safe_play(wall_sound)

        # Gol
        if self.ball_x <= 0:
            self.score[1] += 1
            self.reset_ball("ai")
        elif self.ball_x + BALL_SIZE >= WIDTH:
            self.score[0] += 1
            self.reset_ball("player")

        # Revisar si alguien alcanzó la puntuación máxima
        if self.score[0] >= self.max_score:
            self.game_state = "GAME_OVER"
            self.winner = "player"
        elif self.score[1] >= self.max_score:
            self.game_state = "GAME_OVER"
            self.winner = "ai"

        # Colisiones con paletas
        ball_rect = pygame.Rect(self.ball_x, self.ball_y, BALL_SIZE, BALL_SIZE)
        player_rect = pygame.Rect(35, self.player_y, PADDLE_WIDTH, PADDLE_HEIGHT)
        ai_rect = pygame.Rect(WIDTH - 35 - PADDLE_WIDTH, self.ai_y, PADDLE_WIDTH, PADDLE_HEIGHT)

        if ball_rect.colliderect(player_rect) and self.ball_vel_x < 0:
            self.ball_x = 35 + PADDLE_WIDTH
            offset = (self.ball_y + BALL_SIZE / 2) - (self.player_y + PADDLE_HEIGHT / 2)
            self.ball_vel_y = offset * 0.3
            self.ball_vel_x *= -1
            self.optimal_position = self.calculate_ai_target()
            safe_play(paddle_sound)

        elif ball_rect.colliderect(ai_rect) and self.ball_vel_x > 0:
            self.ball_x = WIDTH - 35 - PADDLE_WIDTH - BALL_SIZE
            offset = (self.ball_y + BALL_SIZE / 2) - (self.ai_y + PADDLE_HEIGHT / 2)
            self.ball_vel_y = offset * 0.3
            self.ball_vel_x *= -1
            safe_play(paddle_sound)

    # ===============================
    # BUCLE PRINCIPAL
    # ===============================
    def run(self):
        running = True
        while running:
            self.clock.tick(FPS)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    self.game_state = False

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        if self.game_state == "RUNNING":
                            self.game_state = "PAUSED"
                        elif self.game_state == "PAUSED":
                            self.game_state = "RUNNING"
                    elif event.key == pygame.K_RETURN:
                        if self.menu_button_rect and self.menu_button_rect.collidepoint(pygame.mouse.get_pos()):
                            self.game_state = "MENU"
                            running = False
                        elif hasattr(self, "restart_button_rect") and self.restart_button_rect and self.restart_button_rect.collidepoint(pygame.mouse.get_pos()):
                            self.reset_game()
                            self.game_state = "RUNNING"

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.game_state == "PAUSED" and self.menu_button_rect:
                        if self.menu_button_rect.collidepoint(event.pos):
                            self.game_state = "MENU"
                            running = False
                    elif self.game_state == "GAME_OVER":
                        if self.menu_button_rect.collidepoint(event.pos):
                            self.game_state = "MENU"
                            running = False
                        elif hasattr(self, "restart_button_rect") and self.restart_button_rect.collidepoint(event.pos):
                            self.reset_game()
                            self.game_state = "RUNNING"

            if self.game_state == "RUNNING":
                self.update()

            self.draw()

        return self.game_state

# ===============================
# FUNCIÓN DE INICIO
# ===============================
def run_singleplayer():
    final_state = PongGame().run()
    return final_state

# ===============================
# EJECUCIÓN DIRECTA
# ===============================
if __name__ == "__main__":
    run_singleplayer()
    sys.exit()
